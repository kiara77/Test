public abstract class Space {
	int longueur;
	int largeur;
	Obstacles obstacles;
//	Vector <Shape> shape;
	Ball ball;
	
	Space(){
		ball = new Ball();
		longueur=21;
		largeur=47;
//		shape=new Vector <Shape>();
	}
	public abstract JPanelDraw returnJPanel();
	
	public abstract boolean collide();
	
	public abstract Point collidePoint();
}
