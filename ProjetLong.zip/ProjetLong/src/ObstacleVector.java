import java.util.Vector;


public class ObstacleVector extends Shape implements Obstacles{
	
	Vector <Point> vectObs;
	@Override
	public void setObstacles(int x, int y) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isObstacle(int x, int y) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void printObstacle() {
		// TODO Auto-generated method stub
		
	}

}
