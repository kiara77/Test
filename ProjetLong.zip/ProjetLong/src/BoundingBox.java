
public class BoundingBox extends Shape{
	int x1,y1,x2,y2;
	
	public BoundingBox(){
		
		
	}
	
}
