import java.util.Vector;


public class Shape {
	Vector <Point> shape;

	public Shape (){

	}
	public BoundingBox getBoundingBox(){
		BoundingBox b= new BoundingBox();
		return b;
	}

}
