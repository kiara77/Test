
public class GameRules {
	
	public boolean gameOver(LevelState state){
		return false;
	}
}
